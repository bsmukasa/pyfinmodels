#include <iostream>
#include <sstream>
#include <fstream>
#include <iterator>

using namespace std;
#define __VAR_CALCULATION__
#include "HWTree.H"

template <class T>
class csv_istream_iterator : public iterator<input_iterator_tag, T> {
    istream * _input;
    char _delim;
    string _value;
public:

    csv_istream_iterator(char delim = ',') : _input(0), _delim(delim) {
    }

    csv_istream_iterator(istream & in, char delim = ',') : _input(&in), _delim(delim) {
        ++ * this;
    }

    const T operator *() const {
        istringstream ss(_value);
        T value;
        ss >> value;
        return value;
    }

    istream & operator ++() {
        if (!getline(*_input, _value, _delim)) {
            _input = 0;
        }
        return *_input;
    }

    bool operator !=(const csv_istream_iterator & rhs) const {
        return _input != rhs._input;
    }
};

std::map<double, double> getDiff(std::map<double, double>& a, std::map<double, double>& b) {
    std::map<double, double> diff;
    for (std::map<double, double>::iterator it = a.begin(); it != a.end(); it++) {
        diff[it->first] = b[it->first] - a[it->first];
    }
    return diff;
}

vector<std::map<double, double> > getYieldCurveDiffs(vector<std::map<double, double> >& yieldCurves) {
    vector<std::map<double, double> >::iterator it = yieldCurves.begin();
    vector<std::map<double, double> >::iterator it_10 = it + 10;
    vector<std::map<double, double> > diffVector;
    while (it != yieldCurves.end() && it_10 != yieldCurves.end()) {
        diffVector.insert(diffVector.end(), getDiff(*it, *it_10));
        it++;
        it_10++;
    }

    return diffVector;
}

std::map<double, double> applyDiffsToZeros(std::map<double, double>& zeros, std::map<double, double>& diff) {
    std::map<double, double> zerosMod;
    TermStructure term(diff); // hack, just to be able to interpolate the values
    for (std::map<double, double>::iterator it = zeros.begin(); it != zeros.end(); it++) {
        zerosMod[it->first] = it->second + term.getRate(it->first);
    }

    return zerosMod;
}

std::map<double, double> getInputZeroCoupons() {
    std::map<double, double> yield_curve;

    yield_curve[1.0 / 12.0] = 0.22994 / 100;
    yield_curve[1.0 / 4.0] = 0.35022 / 100;
    yield_curve[1] = 0.4478 / 100;
    yield_curve[2] = 0.50479 / 100;
    yield_curve[3] = 0.56793 / 100;
    yield_curve[4] = 0.94326 / 100;
    yield_curve[5] = 1.26067 / 100;

    return yield_curve;
}

std::vector<std::map<double, double> > readVarFile() {
    std::vector<std::map<double, double> > yieldCurveVector;
    ifstream fin("varfile.csv");

    if (fin) {
        csv_istream_iterator<double> c(fin);
        int count = 1;
        do {
            std::map<double, double> y;
            double arr[] = {1.0, 3.0, 6.0, 12.0, 24.0, 36.0,60.0};
            for (int i = 0; i <=6; i++) {
                y[arr[i]/12.0] = (*c)/100;
                ++c;
            }

            yieldCurveVector.insert(yieldCurveVector.end(), y);
            std::cout << "Read line " << count++ << std::endl;
        } while ((c != csv_istream_iterator<double>()));
        fin.close();
    }

    std::cout << "First Record... ";
    for (std::map<double, double>::iterator it = yieldCurveVector[0].begin(); it != yieldCurveVector[0].end(); it++)
        std::cout << it->first << "-" << it->second << endl;

    std::cout << "Last Record... ";
    for (std::map<double, double>::iterator it = yieldCurveVector[yieldCurveVector.size() - 2].begin(); it != yieldCurveVector[yieldCurveVector.size() - 2].end(); it++)
        std::cout << it->first << "-" << it->second << endl;

    return yieldCurveVector;
}

void doGreeks(HWTreeOutput hwOrig, double a, double sigma, int iterations, int optionMaturity, std::map<double, double> zeros, double bondCouponRate, double bondCouponLength, double bondMaturity, double strike, OptionSide side, bool debugtree) {
    typedef std::map<double, double> MAP_TYPE;
    MAP_TYPE zeros_minus, zeros_plus, zeros_minus_minus, zeros_plus_plus;
    
    double parallel_shift_delta = 0.0001; 
    for ( MAP_TYPE::iterator it = zeros.begin(); it != zeros.end(); it++ )  {   
        zeros_minus[it->first] = it->second - parallel_shift_delta;
        zeros_plus[it->first] = it->second + parallel_shift_delta;
    }
    
    HWTreeOutput hwmOutput = HWTreePricer(a, sigma, iterations, optionMaturity, zeros_minus, bondCouponRate, bondCouponLength, bondMaturity, strike, side, debugtree);
    HWTreeOutput hwpOutput = HWTreePricer(a, sigma, iterations, optionMaturity, zeros_plus, bondCouponRate, bondCouponLength, bondMaturity, strike, side, debugtree);
    
    HWTreeOutput hwmsigOutput = HWTreePricer(a, sigma - parallel_shift_delta, iterations, optionMaturity, zeros, bondCouponRate, bondCouponLength, bondMaturity, strike, side, debugtree);
    HWTreeOutput hwpsigOutput = HWTreePricer(a, sigma + parallel_shift_delta, iterations, optionMaturity, zeros, bondCouponRate, bondCouponLength, bondMaturity, strike, side, debugtree);
    
    double eODV01, aODV01;
    eODV01 = (hwmOutput.europeanOPrice - hwpOutput.europeanOPrice)/(2 * hwOrig.europeanOPrice * parallel_shift_delta);
    aODV01 = (hwmOutput.americanOPrice - hwpOutput.americanOPrice)/(2 * hwOrig.americanOPrice * parallel_shift_delta);
    
    double eOGamma, aOGamma;
    eOGamma = (hwmOutput.europeanOPrice - 2 * hwOrig.europeanOPrice +  hwpOutput.europeanOPrice)/(100 * hwOrig.europeanOPrice * pow((double)parallel_shift_delta, 2));
    aOGamma = (hwmOutput.americanOPrice - 2 * hwOrig.americanOPrice +  hwpOutput.americanOPrice)/(100 * hwOrig.americanOPrice * pow((double)parallel_shift_delta, 2));
    
    double eOVega, aOVega;
    eOVega = (hwmsigOutput.europeanOPrice - hwpsigOutput.europeanOPrice)/(2 * hwOrig.europeanOPrice * parallel_shift_delta);
    aOVega = (hwmsigOutput.americanOPrice - hwpsigOutput.americanOPrice)/(2 * hwOrig.americanOPrice * parallel_shift_delta);
    
    printf("[Greeks Calculations on Options - European Option Duration: %.5f, American Option Duration: %.5f, European Option Convexity: %.5f, American Option Convexity: %.5f, European Option Vega: %.5f, American Option Vega: %.5f]", eODV01, aODV01, eOGamma, aOGamma, eOVega, aOVega);
    
}

#ifdef __VAR_CALCULATION__
int main(int argc, char * args[]) {

    std::vector<std::map<double, double> > yieldCurveVector = readVarFile();
    vector<std::map<double, double> > diffs = getYieldCurveDiffs(yieldCurveVector);
    std::cout << "Diff Completed, size of diff vector is " << diffs.size() << std::endl;

    std::map<double, double> zeros = getInputZeroCoupons();
    HWTreeOutput hwPricesOrig = HWTreePricer(0.002, 0.0115, 100, 1, zeros, 0.1, 0.5, 5, 1.42759, PUT, false);
    std::vector<HWTreeOutput> outputVector;
    for (vector<std::map<double, double> >::iterator it = diffs.begin(); it != diffs.end(); it++) {
        std::map<double, double> zerosMod = applyDiffsToZeros(zeros, *it);
        HWTreeOutput hwOutput = HWTreePricer(0.002, 0.0115, 100, 1, zerosMod, 0.1, 0.5, 5, hwPricesOrig.bondPrice, PUT, false);
        outputVector.insert(outputVector.end(), hwOutput);
    }
    std::vector<double> lossEuropean, lossAmerican;
    for (std::vector<HWTreeOutput>::iterator it = outputVector.begin(); it != outputVector.end(); it++) {
        lossEuropean.insert(lossEuropean.end(),(*it).europeanOPrice - hwPricesOrig.europeanOPrice);
        lossAmerican.insert(lossAmerican.end(),(*it).americanOPrice - hwPricesOrig.americanOPrice);
    }
    
    sort(lossEuropean.begin(), lossEuropean.end());
    
    double pe_99 = *(lossEuropean.begin()+int(lossEuropean.size() * 0.99)); 
    double pe_95 = *(lossEuropean.begin()+int(lossEuropean.size() * 0.95)); 
    std::cout << "European Option 1% VAR is " << pe_99 << std::endl;
    std::cout << "European Option 5% VAR is " << pe_95 << std::endl;
    
    double pa_99 = *(lossAmerican.begin()+int(lossAmerican.size() * 0.99)); 
    double pa_95 = *(lossAmerican.begin()+int(lossAmerican.size() * 0.95)); 
    std::cout << "American Option 1% VAR is " << pa_99 << std::endl;
    std::cout << "American Option 5% VAR is " << pa_95 << std::endl;
    
    return 0;
}

#else
int main(int argc, const char * argv[]) {
    // change the getInputZeroCoupon to return the right ZCBs
    std::map<double, double> zeros = getInputZeroCoupons();
    HWTreeOutput hwOutput = HWTreePricer(0.002, 0.0115, 100, 1, zeros, 0.1, 0.5, 5, 0.3, PUT, false);
    HWTreeOutput hwOutput1 = HWTreePricer(0.002, 0.0115, 100, 1, zeros, 0.1, 0.5, 5, hwOutput.bondPrice, PUT, false);
    //HWTreeOutput hwOutput1 = HWTreePricer(0.002, 0.0115, 1000, 1, zeros, 0.1, 0.5, 5, 0.3, CALL, false);
    doGreeks(hwOutput1, 0.002, 0.0115, 100, 1, zeros, 0.1, 0.5, 5, hwOutput.bondPrice, PUT, false);
    return 0;
}
#endif